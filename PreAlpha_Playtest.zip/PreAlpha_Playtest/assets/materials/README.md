# adding game textures

the material system uses four 128x128 images for a finished surface:

- albedo - the actual colors i see on the surface
- normal - changes the direction each pixel appears to face when it is lit
- specular - controls how much each pixel reflects the lights
- smoothness - controls whether that reflection is tight and clean or wide and rough

put a source image anywhere inside this project, then run this from the project folder:

```powershell
python tools/build_game_textures.py --add my_material path/to/image.png
```

that resizes the source to a 128x128 albedo, generates the other three maps in
`assets/textures/game/`, and registers the new material in `game.materials`.

the normal generator converts the albedo to brightness and treats it like height. it combines
a 3x3 sobel slope for crisp pixel detail with a wider three-texel slope for larger panels,
stains, and seams, then stores the normalized tangent-space direction as rgb. it is still
guessing because a color texture does not know the real shape of an object, so authored normals
remain useful when the shape needs to be exact.

more exactly, the runtime does this for each pixel:

```text
y  = round(0.2126r + 0.7152g + 0.0722b)
h  = y / 255
fine dx/dy = 3x3 sobel slopes / 4
broad dx = (h(x+3,y)-h(x-3,y)) / 3
broad dy = (h(x,y+3)-h(x,y-3)) / 3
n  = normalize(-(4*fine dx+1.4*broad dx),
               -(4*fine dy+1.4*broad dy), 1)
rgb = round((n * 0.5 + 0.5) * 255)
```

the neighbor coordinates clamp at the texture border. the result is a tangent-space direction;
it does not change collision or add geometry. each normal-map mip level is built by decoding a
2x2 group, averaging its directions, and normalizing again. the gpu keeps nearest pixel sampling
inside a mip while blending between mip levels, preventing abrupt distance and grazing-angle
changes.

the specular generator produces a grayscale mask. it separates sharp dark cavities from soft
dark stains by comparing a 3x3 average with an 11x11 neighborhood. neutral exposed edges and
wear reflect more, sharp cavities reflect less, and soft grime receives a broader oily response.
it also checks the material name so floors, walls, crates, doors, panels, pipes, and machinery
do not all behave like the same kind of metal. smoothness is generated separately: bright
smoothness creates a smaller and sharper reflection, while dark smoothness creates a broader,
rougher reflection.

the exact inputs for those two maps are:

```text
saturation = (max(r,g,b) - min(r,g,b)) / max(max(r,g,b), 1)
neutrality = 1 - saturation
brightness = luminance / 255
local average = average luminance in a 3x3 window
wide average = average luminance in an 11x11 window
edge = clamp((abs(left-right) + abs(up-down)) / 176)
variation = clamp(abs(luminance-local average) / 44)
cavity = clamp((local average-luminance) / 38)
stain = clamp((wide average-local average) / 48) * (1-0.65*edge)
wear = clamp((local average-wide average) / 50) * neutrality
exposed edge = edge * (0.35+0.65*neutrality) * (0.40+0.60*brightness)

material signal = 0.18 + 0.30*neutrality + 0.08*brightness
                + exposed edge*profile edge gain + 0.12*variation
                + stain*profile stain gain + 0.18*wear
specular = profile specular base + profile specular range*material signal
         - 28*cavity

finish signal = 0.38*neutrality + 0.18*brightness
              + 0.28*(1-variation) + 0.10*wear
smoothness = profile smoothness base + profile smoothness range*finish signal
           - 104*edge*profile edge roughness - 48*cavity
           - 82*stain*profile stain roughness
```

the profile is selected from the material name because the source pixels cannot identify the
physical material. the tuple below is `(spec base, spec range, smooth base, smooth range,
edge gain, edge roughness, stain gain, stain roughness)`:

```text
pipe / machinery / prop        (68,116,88,100,.75,.30,.52,.38)
weapon / door / locker / panel (56,104,82, 92,.62,.40,.44,.44)
puzzle / circuit / emissive    (62,108,96, 88,.55,.28,.38,.30)
crate                          (44, 82,64, 74,.52,.56,.28,.66)
floor                          (38, 78,48, 66,.45,.70,.48,.58)
wall                           (42, 84,52, 72,.46,.60,.46,.60)
ceiling                        (44, 88,58, 76,.48,.54,.40,.54)
everything else                (38, 76,52, 68,.42,.60,.36,.58)
```

the resulting specular and smoothness values clamp to 0..255 and round to the nearest multiple
of 4. the runtime packs them into an `rg8` texture-array layer: specular in red and smoothness
in green.

these maps do not have lights baked into them. they only describe the surface. the world
shader combines them with the current sun, room lights, flashlight, camera angle, light
distance, and shadows every frame.

technically, the shader reconstructs a tangent frame from screen-space position and uv
derivatives, transforms the sampled tangent normal into world space, and uses that normal for
diffuse and reflection calculations. roughness is derived as `1-smoothness`. specular controls
base reflectance, smoothness changes the width of the anisotropic beckmann highlight, and a
fresnel term strengthens reflection at grazing angles. only after that does it apply each
light's color, distance falloff, direction, and shadow visibility.

i can also add a line manually:

```text
material my_material assets/textures/game/my_material.png auto auto auto
```

using `auto` makes the game generate that particular map in memory when it loads. i can mix
automatic and custom maps on one material. the generated data is uploaded into gpu texture
arrays, then its temporary cpu memory is released. all arrays use nearest filtering so the
pixels stay crisp. `--sync-manifest` writes generated maps to png files when i want permanent
assets instead.

the first 16 material lines need to stay first and in the same order because saved levels use
their numeric layer positions. custom materials go underneath them.
