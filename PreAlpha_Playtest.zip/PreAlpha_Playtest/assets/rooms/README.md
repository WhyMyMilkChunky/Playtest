# Authored rooms

The in-game room creator stores reusable room prefabs here as `.s3droom` files.

Run `tools\launch_room_editor.cmd` after building the game once. The editor starts
with a valid 24 x 8 x 24 metre room shell. Its main workflow is:

1. Build the room from box geometry and assign each piece a material name from
   `assets/materials/game.materials`.
2. Place connections exactly on room bounds. Their floor Y value supports stairs
   and elevated routes.
3. Add a safe area behind every connection so gameplay objects cannot obstruct
   entrances or progression.
4. Add fixed prop sockets, optional procedural decoration zones, and point lights.
5. Save, validate, then use **Register in theme**. This adds or updates the room in
   `assets/dungeons/cyber_industrial.dungeon` without duplicating definitions.
6. Use **Preview in dungeon** before registering to generate a temporary small test
   dungeon that forces the room. Press F2 in that preview to return to the creator.

Unused connection openings are sealed at generation time, so a room can expose
several possible connection points without leaving holes in a particular layout.
Collision remains active even when world-render culling hides a room.

To add your own texture later, put a 128 x 128 albedo PNG in
`assets/textures/game`, add one `material` line to `assets/materials/game.materials`,
and use `auto` for normal/specular/smoothness if you want the game to generate those
maps without changing the pixel resolution. The new name appears in the editor's
material preset list on its next launch.
