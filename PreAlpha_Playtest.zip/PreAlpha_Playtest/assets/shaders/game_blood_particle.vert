#version 460 core

#include "include/s3d_backend.glsl"

layout(location = 0) in vec3 aPosition;
layout(location = 2) in vec2 aTcoord;
layout(location = 3) in vec4 aPositionAndSize;
layout(location = 4) in vec4 aColorAndSeed;

#if defined(S3D_VULKAN)
S3D_RESOURCE(0, 0) uniform BloodParticleFrame
{
	mat4 u_viewProjection;
	vec3 u_cameraRight;
	vec3 u_cameraUp;
};
#else
uniform mat4 u_viewProjection;
uniform vec3 u_cameraRight;
uniform vec3 u_cameraUp;
#endif

layout(location = 0) out vec2 particleUv;
layout(location = 1) out vec3 particleColor;
layout(location = 2) flat out float shapeSeed;

void main()
{
	vec3 worldPosition = aPositionAndSize.xyz +
		u_cameraRight * aPosition.x * aPositionAndSize.w +
		u_cameraUp * aPosition.y * aPositionAndSize.w;
	particleUv = aTcoord;
	particleColor = aColorAndSeed.rgb;
	shapeSeed = aColorAndSeed.w;
	gl_Position = S3DClipPosition(
		u_viewProjection * vec4(worldPosition, 1.0));
}
