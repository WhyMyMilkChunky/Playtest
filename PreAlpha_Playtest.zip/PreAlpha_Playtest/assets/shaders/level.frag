#version 460 core

#include "include/s3d_backend.glsl"

layout(location = 0) out vec4 FragColor;

#if defined(S3D_VULKAN)
#include "include/game_world_gpu.glsl"
layout(location = 0) in vec3 position;
layout(location = 1) in vec3 normal;
layout(location = 2) in vec3 instanceColor;
layout(location = 3) in vec2 boxUv;
layout(location = 4) flat in int materialIndex;
layout(location = 5) in float bakedAmbientOcclusion;
layout(location = 6) flat in vec2 bakedAoFaceSize;
layout(location = 7) flat in int worldChunkIndex;

#define u_sunDirection worldFrame.sunDirection.xyz
#define u_cameraPosition worldFrame.cameraPosition.xyz
#define u_fogColor worldFrame.fogColor.xyz
#define u_fogNear worldFrame.renderSettings.x
#define u_fogFar worldFrame.renderSettings.y
#define u_normalStrength worldFrame.renderSettings.z
#define u_specularStrength worldFrame.renderSettings.w
#define u_aoEnabled int(worldFrame.aoSettings.x)
#define u_aoRadius worldFrame.aoSettings.y
#define u_aoStrength worldFrame.aoSettings.z
#define u_fullbright int(worldFrame.aoSettings.w)
#define u_floorMaterial worldFrame.materialIds0.x
#define u_wallMaterial worldFrame.materialIds0.y
#define u_ceilingMaterial worldFrame.materialIds0.z
#define u_panelMaterial worldFrame.materialIds0.w
#define u_doorLeftMaterial worldFrame.materialIds1.x
#define u_doorRightMaterial worldFrame.materialIds1.y
#define u_fixedPuzzleFirstMaterial worldFrame.materialIds1.z
#define u_fixedPuzzleLastMaterial worldFrame.materialIds1.w
#define u_emissiveMaterial worldFrame.counts.x
#define u_shadowBias worldFrame.shadowSettings.x
#define u_shadowDarkness worldFrame.shadowSettings.y
#else
in vec3 position;
in vec3 normal;
in vec3 instanceColor;
in vec2 boxUv;
flat in int materialIndex;
in float bakedAmbientOcclusion;
flat in vec2 bakedAoFaceSize;

uniform vec3 u_sunDirection;
uniform vec3 u_cameraPosition;
uniform vec3 u_fogColor;
uniform float u_fogNear;
uniform float u_fogFar;
uniform float u_normalStrength;
uniform float u_specularStrength;
uniform int u_aoEnabled;
uniform float u_aoRadius;
uniform float u_aoStrength;
uniform int u_floorMaterial;
uniform int u_wallMaterial;
uniform int u_ceilingMaterial;
uniform int u_panelMaterial;
uniform int u_doorLeftMaterial;
uniform int u_doorRightMaterial;
uniform int u_fixedPuzzleFirstMaterial;
uniform int u_fixedPuzzleLastMaterial;
uniform int u_emissiveMaterial;
uniform int u_fullbright;
uniform int u_chunkLightCount;
uniform int u_chunkLightIndices[24];
uniform vec3 u_lightPositions[24];
uniform vec3 u_lightColors[24];
uniform vec3 u_lightDirections[24];
uniform vec4 u_lightParameters[24];
uniform int u_lightShadowSlots[24];
uniform vec3 u_shadowLightPositions[24];
uniform float u_shadowFarPlanes[24];
uniform float u_shadowBias;
uniform float u_shadowDarkness;
uniform int u_bloodStainCount;
uniform vec4 u_bloodStainPositions[16];
uniform vec4 u_bloodStainNormals[16];
uniform vec4 u_bloodStainAxesU[16];
uniform vec4 u_bloodStainAxesV[16];
#endif

S3D_RESOURCE(1, 0) uniform sampler2DArray u_albedoMaps;
S3D_RESOURCE(1, 1) uniform sampler2DArray u_normalMaps;
S3D_RESOURCE(1, 2) uniform sampler2DArray u_surfaceMaps;
S3D_RESOURCE(2, 4) uniform samplerCubeArray u_shadowMaps;

int ChunkLightCount()
{
#if defined(S3D_VULKAN)
	return worldChunkIndex < 0 ? worldFrame.counts.y :
		worldChunks[worldChunkIndex].header.x;
#else
	return u_chunkLightCount;
#endif
}

int ChunkLightIndex(int index)
{
#if defined(S3D_VULKAN)
	if (worldChunkIndex < 0) return index;
	ivec4 packed = worldChunks[worldChunkIndex].lightIndices[index / 4];
	return packed[index & 3];
#else
	return u_chunkLightIndices[index];
#endif
}

vec3 LightPosition(int index)
{
#if defined(S3D_VULKAN)
	return worldFrame.lights[index].position.xyz;
#else
	return u_lightPositions[index];
#endif
}

vec3 LightColor(int index)
{
#if defined(S3D_VULKAN)
	return worldFrame.lights[index].color.xyz;
#else
	return u_lightColors[index];
#endif
}

vec3 LightDirection(int index)
{
#if defined(S3D_VULKAN)
	return worldFrame.lights[index].direction.xyz;
#else
	return u_lightDirections[index];
#endif
}

vec4 LightParameters(int index)
{
#if defined(S3D_VULKAN)
	return worldFrame.lights[index].parameters;
#else
	return u_lightParameters[index];
#endif
}

int LightShadowSlot(int index)
{
#if defined(S3D_VULKAN)
	return worldFrame.lights[index].shadow.x;
#else
	return u_lightShadowSlots[index];
#endif
}

vec4 ShadowPositionFar(int slot)
{
#if defined(S3D_VULKAN)
	return worldFrame.shadowPositionFar[slot];
#else
	return vec4(u_shadowLightPositions[slot], u_shadowFarPlanes[slot]);
#endif
}

int BloodStainCount()
{
#if defined(S3D_VULKAN)
	return worldChunkIndex < 0 ? 0 : worldChunks[worldChunkIndex].header.y;
#else
	return u_bloodStainCount;
#endif
}

vec4 BloodPosition(int index)
{
#if defined(S3D_VULKAN)
	return worldChunks[worldChunkIndex].bloodPositions[index];
#else
	return u_bloodStainPositions[index];
#endif
}

vec4 BloodNormal(int index)
{
#if defined(S3D_VULKAN)
	return worldChunks[worldChunkIndex].bloodNormals[index];
#else
	return u_bloodStainNormals[index];
#endif
}

vec4 BloodAxisU(int index)
{
#if defined(S3D_VULKAN)
	return worldChunks[worldChunkIndex].bloodAxesU[index];
#else
	return u_bloodStainAxesU[index];
#endif
}

vec4 BloodAxisV(int index)
{
#if defined(S3D_VULKAN)
	return worldChunks[worldChunkIndex].bloodAxesV[index];
#else
	return u_bloodStainAxesV[index];
#endif
}

float Pow5(float value)
{
	float squared = value * value;
	return squared * squared * value;
}

float SpecularReflectance(float specularLevel)
{
	return mix(0.025, 0.28, smoothstep(0.04, 0.82, specularLevel));
}

float PixelLightResponse(float value)
{
	float banded = floor(clamp(value, 0.0, 1.0) * 12.0 + 0.5) / 12.0;
	return mix(value, banded, 0.58);
}

vec3 TextureLockedPosition(vec3 worldPosition, vec3 absoluteNormal, vec2 materialUv,
	float textureScale, bool fixedImage)
{
	if (fixedImage) return worldPosition;
	vec2 texelCenter = (floor(materialUv * 128.0) + 0.5) / 128.0;
	vec2 surfaceOffset = (texelCenter - materialUv) / textureScale;
	if (absoluteNormal.y > max(absoluteNormal.x, absoluteNormal.z))
		return worldPosition + vec3(surfaceOffset.x, 0.0, surfaceOffset.y);
	if (absoluteNormal.x > absoluteNormal.z)
		return worldPosition + vec3(0.0, surfaceOffset.y, surfaceOffset.x);
	return worldPosition + vec3(surfaceOffset.x, surfaceOffset.y, 0.0);
}

vec2 MaterialTexelScreenOffset(vec2 materialUv)
{
	vec2 texelCenter = (floor(materialUv * 128.0) + 0.5) / 128.0;
	vec2 materialOffset = texelCenter - materialUv;
	vec2 uvDx = dFdx(materialUv);
	vec2 uvDy = S3D_DFDY(materialUv);
	float determinant = uvDx.x * uvDy.y - uvDx.y * uvDy.x;
	if (abs(determinant) < 0.0000001) return vec2(0.0);
	return vec2(
		(materialOffset.x * uvDy.y - materialOffset.y * uvDy.x) / determinant,
		(uvDx.x * materialOffset.y - uvDx.y * materialOffset.x) / determinant);
}

mat3 CotangentFrame(vec3 surfaceNormal, vec3 surfacePosition, vec2 uv)
{
	vec3 positionDx = dFdx(surfacePosition);
	vec3 positionDy = S3D_DFDY(surfacePosition);
	vec2 uvDx = dFdx(uv);
	vec2 uvDy = S3D_DFDY(uv);
	vec3 perpendicularX = cross(positionDy, surfaceNormal);
	vec3 perpendicularY = cross(surfaceNormal, positionDx);
	vec3 tangent = perpendicularX * uvDx.x + perpendicularY * uvDy.x;
	vec3 bitangent = perpendicularX * uvDx.y + perpendicularY * uvDy.y;
	float scale = inversesqrt(max(max(dot(tangent, tangent),
		dot(bitangent, bitangent)), 0.00001));
	return mat3(tangent * scale, bitangent * scale, surfaceNormal);
}

float RelayDiffuse(vec3 normalValue, vec3 viewDirection, vec3 lightDirection,
	float roughness)
{
	float normalLight = dot(normalValue, lightDirection);
	float normalView = max(dot(normalValue, viewDirection), 0.0);
	float wrap = 0.035 + roughness * 0.18;
	float wrappedLight = clamp((normalLight + wrap) / (1.0 + wrap), 0.0, 1.0);
	float viewReturn = 0.82 + 0.18 * (1.0 - Pow5(1.0 - normalView));
	return wrappedLight * viewReturn * (1.0 - roughness * 0.12);
}

vec3 BeckmannReflection(vec3 lightColor, vec3 normalValue, vec3 tangentValue,
	vec3 bitangentValue, vec3 viewDirection, vec3 lightDirection,
	float specularLevel, float smoothness, float strength)
{
	float normalLight = max(dot(normalValue, lightDirection), 0.0);
	float normalView = max(dot(normalValue, viewDirection), 0.0);
	if (normalLight <= 0.0 || normalView <= 0.0 || strength <= 0.0)
		return vec3(0.0);
	vec3 halfway = normalize(viewDirection + lightDirection);
	float normalHalf = max(dot(normalValue, halfway), 0.001);
	float viewHalf = max(dot(viewDirection, halfway), 0.001);
	float roughness = clamp(1.0 - smoothness, 0.12, 0.92);
	// Anisotropic Beckmann slopes keep industrial highlights from becoming round orbs.
	float alphaX = max(roughness * 0.72, 0.075);
	float alphaY = max(roughness * 1.28, 0.105);
	float slopeX = dot(halfway, tangentValue) / alphaX;
	float slopeY = dot(halfway, bitangentValue) / alphaY;
	float normalHalf2 = normalHalf * normalHalf;
	float distribution = exp(-(slopeX * slopeX + slopeY * slopeY) / normalHalf2) /
		(3.14159265 * alphaX * alphaY * normalHalf2 * normalHalf2);
	float geometry = min(1.0, min(2.0 * normalHalf * normalView / viewHalf,
		2.0 * normalHalf * normalLight / viewHalf));
	float reflectance = SpecularReflectance(specularLevel);
	float fresnel = reflectance + (1.0 - reflectance) * Pow5(1.0 - viewHalf);
	float reflectedEnergy = distribution * geometry * fresnel /
		max(4.0 * normalView, 0.001);
	// This renderer writes directly to an 8-bit target, so bound unresolved peaks.
	return lightColor * min(reflectedEnergy * strength * 1.25, 1.0);
}

vec3 SurfaceReflection(vec3 lightColor, vec3 normalValue, vec3 tangentValue,
	vec3 bitangentValue, vec3 viewDirection, vec3 lightDirection,
	float specularLevel, float smoothness, float strength)
{
	return BeckmannReflection(lightColor, normalValue, tangentValue,
		bitangentValue, viewDirection, lightDirection, specularLevel,
		smoothness, strength);
}

vec3 EnvironmentReflection(vec3 environmentColor, vec3 normalValue,
	vec3 viewDirection, float specularLevel, float smoothness, float strength)
{
	float normalView = max(dot(normalValue, viewDirection), 0.0);
	float reflectance = SpecularReflectance(specularLevel);
	float fresnel = reflectance + (1.0 - reflectance) * Pow5(1.0 - normalView);
	return environmentColor * fresnel * mix(0.24, 0.72, smoothness) * strength;
}

float PointShadowVisibility(int slot, vec3 worldPosition, vec3 normalValue,
	vec3 lightDirection)
{
	if (slot < 0 || slot >= 24) return 1.0;
	vec4 shadowPositionFar = ShadowPositionFar(slot);
	float normalLight = max(dot(normalValue, lightDirection), 0.0);
	vec3 unshiftedFromLight = worldPosition - shadowPositionFar.xyz;
	float receiverDistance = length(unshiftedFromLight);
	// A cubemap texel covers more world space farther from the light. Offset toward
	// the light-facing side of the geometric surface, increasing only at grazing
	// angles where low-resolution point shadows are least stable.
	float worldTexel = receiverDistance * (2.0 / 128.0);
	float grazing = 1.0 - normalLight;
	float normalOffset = worldTexel * mix(0.06, 0.32, grazing);
	vec3 receiverPosition = worldPosition + normalValue * normalOffset;
	vec3 fromLight = receiverPosition - shadowPositionFar.xyz;
	float currentDepth = length(fromLight);
	// Shadow arrays have exactly one mip level; explicit LOD keeps this lookup
	// well-defined even when spotlight rejection diverges across fragments.
	float storedDepth = textureLod(u_shadowMaps,
		vec4(fromLight, float(slot)), 0.0).r * shadowPositionFar.w;
	float receiverBias = u_shadowBias + worldTexel * mix(0.025, 0.12, grazing);
	float lit = currentDepth - receiverBias <= storedDepth ? 1.0 : 0.0;
	return mix(u_shadowDarkness, 1.0, lit);
}

float BloodCellNoise(vec2 cell, float seed)
{
	return fract((cell.x * 0.1031 + cell.y * 0.11369 + seed * 0.13787) *
		(cell.x + cell.y + 19.19));
}

float BloodStainShape(vec2 localPosition, int pattern, float seed)
{
	vec2 cell = floor(localPosition * 9.0);
	float noise = BloodCellNoise(cell, seed);
	if (pattern == 1)
	{
		float taper = mix(0.72, 0.20, clamp(localPosition.y * 0.62 + 0.36,
			0.0, 1.0));
		float mainStreak = abs(localPosition.x) <= taper &&
			localPosition.y >= -0.58 && localPosition.y <= 1.0 ? 1.0 : 0.0;
		float raggedEdge = abs(localPosition.x) <= taper * (0.70 + noise * 0.42) ?
			1.0 : 0.0;
		float drip = abs(localPosition.x + 0.18) <= 0.12 &&
			localPosition.y >= -1.0 && localPosition.y < -0.42 ? 1.0 : 0.0;
		return max(mainStreak * raggedEdge, drip * step(0.22, noise));
	}
	float radiusSquared = dot(localPosition, localPosition);
	if (pattern == 2)
	{
		float edge = 0.76 + noise * 0.28;
		float pool = radiusSquared <= edge * edge ? 1.0 : 0.0;
		float brokenEdge = radiusSquared > 0.86 * 0.86 &&
			radiusSquared < 1.18 * 1.18 && noise > 0.82 ? 1.0 : 0.0;
		return max(pool, brokenEdge);
	}
	if (pattern == 3)
	{
		float dropletRadius = 0.58 + noise * 0.24;
		float droplet = radiusSquared <= dropletRadius * dropletRadius ? 1.0 : 0.0;
		float satellite = radiusSquared > 0.82 * 0.82 &&
			radiusSquared < 1.16 * 1.16 &&
			noise > 0.88 ? 1.0 : 0.0;
		return max(droplet, satellite);
	}
	vec2 directionalPosition = vec2(localPosition.x * 1.08,
		localPosition.y * 0.88);
	float directionalRadiusSquared = dot(directionalPosition,
		directionalPosition);
	float burstRadius = 0.70 + noise * 0.34;
	float burst = directionalRadiusSquared <= burstRadius * burstRadius ? 1.0 : 0.0;
	float satellite = directionalRadiusSquared > 0.92 * 0.92 &&
		directionalRadiusSquared < 1.24 * 1.24 &&
		noise > 0.86 ? 1.0 : 0.0;
	return max(burst, satellite);
}

float WorldBloodMask(vec3 surfacePosition, vec3 surfaceNormal, int stainCount)
{
	float mask = 0.0;
	for (int index = 0; index < stainCount; ++index)
	{
		vec4 packedNormal = BloodNormal(index);
		vec3 stainNormal = packedNormal.xyz;
		if (dot(surfaceNormal, stainNormal) < 0.78) continue;
		vec4 packedPosition = BloodPosition(index);
		vec3 offset = surfacePosition - packedPosition.xyz;
		if (abs(dot(offset, stainNormal)) > 0.095) continue;
		vec4 packedAxisU = BloodAxisU(index);
		vec4 packedAxisV = BloodAxisV(index);
		float width = max(packedAxisU.w, 0.01);
		float height = max(packedAxisV.w, 0.01);
		vec2 localPosition = vec2(
			dot(offset, packedAxisU.xyz) / width,
			dot(offset, packedAxisV.xyz) / height);
		if (any(greaterThan(abs(localPosition), vec2(1.28)))) continue;
		float packedPattern = packedNormal.w;
		int pattern = int(floor(packedPattern));
		float seed = fract(packedPattern) * 97.0;
		mask = max(mask, BloodStainShape(localPosition, pattern, seed) *
			packedPosition.w);
	}
	return mask;
}

vec2 SurfaceHeightGradient(float heightValue, vec2 uv)
{
	vec2 uvDx = dFdx(uv);
	vec2 uvDy = S3D_DFDY(uv);
	float heightDx = dFdx(heightValue);
	float heightDy = S3D_DFDY(heightValue);
	float determinant = uvDx.x * uvDy.y - uvDx.y * uvDy.x;
	if (abs(determinant) < 0.0000001) return vec2(0.0);
	return vec2(
		(heightDx * uvDy.y - heightDy * uvDx.y) / determinant,
		(uvDx.x * heightDy - uvDy.x * heightDx) / determinant);
}

void main()
{
	// Static model materials encode authored UVs as -(layer + 1).
	bool authoredUv = materialIndex < 0;
	int material = authoredUv ? -materialIndex - 1 : materialIndex;
	vec3 geometricNormal = normalize(normal);
	vec3 absoluteNormal = abs(geometricNormal);
	vec2 surface = absoluteNormal.y > max(absoluteNormal.x, absoluteNormal.z) ?
		position.xz : (absoluteNormal.x > absoluteNormal.z ? position.zy : position.xy);
	const float structuralTextureScale = 0.125;
	bool structural = material == u_floorMaterial || material == u_wallMaterial ||
		material == u_ceilingMaterial || material == u_panelMaterial;
	float textureScale = structural ? structuralTextureScale : 0.24;
	bool fixedImage = authoredUv || material == u_doorLeftMaterial ||
		material == u_doorRightMaterial ||
		(material >= u_fixedPuzzleFirstMaterial &&
		material <= u_fixedPuzzleLastMaterial);
	vec2 materialUv = fixedImage ? clamp(boxUv, vec2(0.004), vec2(0.996)) :
		surface * textureScale;
	vec3 materialAlbedo = texture(u_albedoMaps,
		vec3(materialUv, float(material))).rgb;
	vec3 mappedNormal = texture(u_normalMaps,
		vec3(materialUv, float(material))).xyz * 2.0 - 1.0;
	vec2 surfaceProperties = texture(u_surfaceMaps,
		vec3(materialUv, float(material))).rg;
	float specularLevel = surfaceProperties.r;
	float smoothness = surfaceProperties.g;
	mappedNormal.y = -mappedNormal.y;
	mappedNormal.xy *= u_normalStrength;
	mappedNormal = normalize(mappedNormal);
	mat3 surfaceFrame = CotangentFrame(geometricNormal, position, materialUv);
	vec3 mappedWorldNormal = normalize(surfaceFrame * mappedNormal);
	vec3 N = mappedWorldNormal;
	vec3 lightingPosition = TextureLockedPosition(position, absoluteNormal,
		materialUv, textureScale, fixedImage);
	vec3 surfaceTint = material == u_emissiveMaterial ? instanceColor :
		mix(vec3(1.0), instanceColor, 0.42);
	vec3 baseColor = surfaceTint * materialAlbedo;
	float reflectionStrength = u_specularStrength;
	int bloodStainCount = BloodStainCount();
	// The stain count is constant for the chunk draw. Keep derivative operations
	// inside this dynamically uniform branch while skipping all blood work for the
	// overwhelmingly common stain-free chunks.
	if (bloodStainCount > 0)
	{
		float bloodMask = WorldBloodMask(lightingPosition,
			geometricNormal, bloodStainCount);
		baseColor = mix(baseColor, vec3(0.30, 0.0025, 0.006), bloodMask);
		float bloodCell = BloodCellNoise(floor(materialUv * 128.0), 0.731);
		float bloodHeight = bloodMask * (0.84 + bloodCell * 0.16);
		vec2 bloodSlope = clamp(SurfaceHeightGradient(bloodHeight, materialUv),
			vec2(-8.0), vec2(8.0));
		vec3 bloodMappedNormal = normalize(vec3(-bloodSlope * 0.055, 1.0));
		vec3 bloodWorldNormal = normalize(surfaceFrame * bloodMappedNormal);
		N = normalize(mix(N, bloodWorldNormal, bloodMask));
		specularLevel = mix(specularLevel, 1.0, bloodMask);
		smoothness = mix(smoothness, 0.97, bloodMask);
		reflectionStrength *= mix(1.0, 2.10, bloodMask);
	}
	vec3 tangentValue = normalize(surfaceFrame[0] - N * dot(surfaceFrame[0], N));
	vec3 bitangentValue = normalize(cross(N, tangentValue));

	if (u_fullbright != 0)
	{
		FragColor = vec4(baseColor, 1.0);
		return;
	}
	vec3 viewDirection = normalize(u_cameraPosition - lightingPosition);
	float roughness = clamp(1.0 - smoothness, 0.08, 0.96);
	float hemisphere = N.y * 0.5 + 0.5;
	float ambientOcclusion = 1.0;
	// u_aoEnabled is uniform for the draw, so derivatives remain in uniform
	// control flow while the disabled path skips every AO-only operation.
	if (u_aoEnabled != 0)
	{
		vec2 texelScreenOffset = MaterialTexelScreenOffset(materialUv);
		float texelBakedAo = bakedAmbientOcclusion + dFdx(bakedAmbientOcclusion) *
			texelScreenOffset.x + S3D_DFDY(bakedAmbientOcclusion) *
			texelScreenOffset.y;
		float bakedAoBand = floor(clamp(texelBakedAo, 0.0, 1.0) * 16.0 + 0.5) /
			16.0;
		if (bakedAoFaceSize.x > 0.0 && bakedAoFaceSize.y > 0.0)
		{
			vec2 faceUv = clamp(boxUv, vec2(0.0), vec2(1.0));
			vec2 edgeDistance = min(faceUv, vec2(1.0) - faceUv) * bakedAoFaceSize;
			float contactDistance = min(edgeDistance.x, edgeDistance.y);
			float reach = max(u_aoRadius, 0.05);
			float contactWeight = 1.0 - smoothstep(reach * 0.08, reach,
				contactDistance);
			bakedAoBand = mix(1.0, bakedAoBand, contactWeight);
		}
		ambientOcclusion = pow(max(bakedAoBand, 0.02),
			max(u_aoStrength, 0.0));
	}
	if (material == u_emissiveMaterial) ambientOcclusion = 1.0;
	float normalCavity = material == u_emissiveMaterial ? 1.0 :
		mix(0.72, 1.0, smoothstep(0.35, 0.98, mappedNormal.z));
	vec3 ambientField = (vec3(0.045, 0.052, 0.072) +
		vec3(0.10, 0.12, 0.17) * hemisphere) * ambientOcclusion * normalCavity;

	vec3 sunDirection = normalize(-u_sunDirection);
	float sunDiffuse = PixelLightResponse(
		RelayDiffuse(N, viewDirection, sunDirection, roughness));
	vec3 sunColor = vec3(0.20, 0.18, 0.15);
	vec3 directDiffuse = baseColor * sunColor * sunDiffuse;
	vec3 directReflection = SurfaceReflection(sunColor, N, tangentValue,
		bitangentValue, viewDirection, sunDirection, specularLevel, smoothness,
		reflectionStrength);
	vec3 reflectionDirection = reflect(-viewDirection, N);
	float reflectedSky = reflectionDirection.y * 0.5 + 0.5;
	vec3 environmentField = mix(u_fogColor * 0.55,
		vec3(0.30, 0.39, 0.52), reflectedSky);
	environmentField *= mix(ambientOcclusion, 1.0, 0.44);

	int chunkLightCount = ChunkLightCount();
	for (int chunkLight = 0; chunkLight < chunkLightCount; chunkLight++)
	{
		int lightIndex = ChunkLightIndex(chunkLight);
		vec4 lightParameters = LightParameters(lightIndex);
		vec3 toLight = LightPosition(lightIndex) - lightingPosition;
		float radius = lightParameters.x;
		float distanceSquared = dot(toLight, toLight);
		if (radius <= 0.0 || distanceSquared >= radius * radius) continue;
		float distanceToLight = sqrt(distanceSquared);
		vec3 lightColor = LightColor(lightIndex);
		vec3 localLightDirection = toLight / max(distanceToLight, 0.001);
		float falloff = 1.0 - distanceToLight / radius;
		float distanceFade = falloff * falloff;
		float attenuation = distanceFade * lightParameters.y;
		float style = lightParameters.z;
		float spot = 1.0;
		if (style > 0.5 && style < 2.5)
		{
			vec3 fromLight = -localLightDirection;
			float coneCosine = lightParameters.w;
			spot = smoothstep(coneCosine, min(coneCosine + 0.18, 0.995),
				dot(fromLight, normalize(LightDirection(lightIndex))));
			// Pixels fully outside a spotlight cannot receive either its lighting or
			// its shadow, so avoid the cubemap fetch and BRDF work below.
			if (spot <= 0.0) continue;
		}
		float shadowVisibility = PointShadowVisibility(
			LightShadowSlot(lightIndex), lightingPosition, geometricNormal,
			localLightDirection);
		// Preserve the original multiplication order for nonzero spot falloff.
		attenuation *= shadowVisibility;
		attenuation *= spot;
		float diffuseResponse = PixelLightResponse(RelayDiffuse(N, viewDirection,
			localLightDirection, roughness));
		directDiffuse += baseColor * lightColor * attenuation *
			diffuseResponse * 0.92;
		directReflection += SurfaceReflection(
			lightColor * attenuation, N, tangentValue, bitangentValue,
			viewDirection, localLightDirection, specularLevel, smoothness,
			reflectionStrength);
	}

	vec3 reflectedLight = min(directReflection + EnvironmentReflection(environmentField,
		N, viewDirection, specularLevel, smoothness, reflectionStrength), vec3(0.72));
	vec3 color = baseColor * ambientField * 1.62 + directDiffuse * 1.62 + reflectedLight;
	if (material == u_emissiveMaterial)
		color += instanceColor * materialAlbedo * 0.86;
	float distanceToCamera = length(position - u_cameraPosition);
	float fog = smoothstep(u_fogNear, u_fogFar, distanceToCamera);
	color = mix(color, u_fogColor, fog);
	FragColor = vec4(color, 1.0);
}
