#ifndef S3D_GAME_WORLD_GPU_GLSL
#define S3D_GAME_WORLD_GPU_GLSL

struct S3DWorldLight
{
	vec4 position;
	vec4 color;
	vec4 direction;
	vec4 parameters;
	ivec4 shadow;
};

S3D_RESOURCE(0, 0) uniform S3DWorldFrameBlock
{
	mat4 viewProjection;
	vec4 sunDirection;
	vec4 cameraPosition;
	vec4 fogColor;
	vec4 renderSettings;
	vec4 aoSettings;
	ivec4 materialIds0;
	ivec4 materialIds1;
	ivec4 counts;
	vec4 shadowSettings;
	S3DWorldLight lights[24];
	vec4 shadowPositionFar[24];
} worldFrame;

struct S3DWorldChunk
{
	ivec4 header;
	ivec4 lightIndices[6];
	vec4 bloodPositions[16];
	vec4 bloodNormals[16];
	vec4 bloodAxesU[16];
	vec4 bloodAxesV[16];
};

S3D_RESOURCE(0, 1) readonly buffer S3DWorldChunkBuffer
{
	S3DWorldChunk worldChunks[];
};

#endif
