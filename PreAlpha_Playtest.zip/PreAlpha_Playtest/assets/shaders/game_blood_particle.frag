#version 460 core

layout(early_fragment_tests) in;

layout(location = 0) in vec2 particleUv;
layout(location = 1) in vec3 particleColor;
layout(location = 2) flat in float shapeSeed;

layout(location = 0) out vec4 FragColor;

float CellNoise(vec2 cell)
{
	return fract((cell.x * 0.1031 + cell.y * 0.11369 + shapeSeed * 7.13787) *
		(cell.x + cell.y + 13.19));
}

void main()
{
	vec2 cell = floor(particleUv * 8.0);
	vec2 pixelPosition = ((cell + 0.5) / 8.0) * 2.0 - 1.0;
	vec2 scaledPosition = vec2(pixelPosition.x * 0.88, pixelPosition.y);
	float radiusSquared = dot(scaledPosition, scaledPosition);
	float occupancy = CellNoise(cell);
	float core = radiusSquared < 0.24 * 0.24 ? 1.0 : 0.0;
	float occupancyMargin = occupancy - 0.34;
	float clusteredPixel = radiusSquared < 0.98 * 0.98 &&
		occupancyMargin > 0.0 &&
		occupancyMargin * occupancyMargin > radiusSquared * 0.46 * 0.46 ? 1.0 : 0.0;
	float satellite = radiusSquared >= 0.84 * 0.84 &&
		radiusSquared < 1.24 * 1.24 &&
		occupancy > 0.90 ? 1.0 : 0.0;
	if (max(core, max(clusteredPixel, satellite)) < 0.5) discard;
	FragColor = vec4(particleColor, 1.0);
}
