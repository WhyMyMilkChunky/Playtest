# Dungeon and material authoring

`cyber_industrial.dungeon` is the live, data-driven definition used by the procedural
generator. You can add room, hallway, prop, facility-adjacency, and material choices
without editing generator code.

Theme variants can reuse a complete definition and override only their identity,
materials, environment, room styles, and prop skins:

```text
inherit assets/dungeons/cyber_industrial.dungeon
theme rust_foundry Rusted Foundry
materials foundry_floor foundry_wall foundry_ceiling foundry_panel door_left door_right emissive
prop_material cover_crate foundry_crate
```

Inheritance must be the first definition and is limited to four levels to reject cycles.
Use `room_floor_material`, `room_wall_material`, or `room_ceiling_material` after
inheritance to override only the intended surface of a special room. Hallways and
unlisted rooms keep the level palette.

Theme geometry can be varied without duplicating the base file. `room_layout`
overrides room size, height, weight, and cover; the existing `room_style` command
controls silhouette and vertical profile. `hall_layout` overrides hallway shape,
width, height, weight, combat use, and elevation support.

## Room modules

### Visual room author

Run `tools\launch_room_editor.cmd` after building the game once, or start
`s3d.exe --room-editor` directly. This opens the dedicated 3D room creator. It authors
reusable `.s3droom` prefabs containing geometry, material assignments, connections,
safe entrance volumes, prop sockets, procedural decoration zones, and lights.

**Preview in dungeon** temporarily injects the room into a generated test layout.
**Register in theme** adds or updates its compact record in the live theme. See
`assets/rooms/README.md` for the complete workflow.

A room is made from one `room` line, one `room_style` line, and one or more
`room_socket` lines with the same room id.

- `room` controls role, minimum/maximum size, height, generation weight, cover layout,
  route eligibility, dead-end use, vertical eligibility, and tags.
- `room_style` controls silhouette, facility zone, internal height profile, lighting,
  entrance-count limits, and the prop-free entrance depth.
- `room_socket` is an explicit doorway connection point. Its side is `west`, `east`,
  `north`, or `south`; offset is the preferred position from `-0.45` to `0.45` across
  that wall; width and height cap the passage that can attach there. Optional elevation
  and connection-kind fields support entrance, exit, stair, and elevated routes. Opposing sockets
  may slide within their safe wall spans to share one exact corridor centerline.
- `room_prefab` points a generator record at its reusable `.s3droom` geometry file.

Give a room at least as many sockets as its `maximum_entrances`. Socket placement is
what makes the passage, wall opening, and interactive door line up exactly.

Supported silhouettes are `rectangular`, `stepped`, `split`, `atrium`, `checkpoint`,
and `reactor`. Supported vertical profiles are `flat`, `raised`, `sunken`, `catwalk`,
and `multi`.

## Hallway and prop modules

Each hallway uses a `hall` line plus a matching `hall_style` line. Hall styles control
cover, whether a passage can act as a large junction, and structural support spacing.
Available shapes include straight/L-shaped, wide combat routes, service passages,
segmented transfers, catwalks, industrial passages, and lifts.

Props use `prop` lines. The generator picks them by category and weight, applies the
room's authored layout profile, scales density and footprint to the room, and keeps
both entrance clearances and the required door-to-room traversal lanes open. Wall
fixtures are decorative and non-colliding; floor cover is collision checked before it
is accepted.

The selector tracks recent main-route choices and total module use. It will not place
the same room module or hallway shape twice in a row when another compatible authored
choice exists, and it reduces the weight of overused modules across the whole draft.

## Vertical rooms, catwalks, and lifts

Upper catwalk routes are graph-planned before geometry is built. A catwalk is only
allowed in a room at least 16 units tall, with exactly two mandatory upper-level doors
and no optional doorway that could bypass progression. The deck joins those two doors,
includes a real elbow when it turns, and always includes recovery stairs so dropping to
the lower floor cannot soft-lock the run. A neighboring room with one raised door gets
a connected mezzanine and stairs rather than an orphan platform.

Floor transitions reserve one shared room center on both floors. The room shells cut a
matching floor/ceiling opening and the gameplay pass builds a continuous shaft, tracked
platform, landing trim, guide structure, and lights through it. The lift record already
owns its platform index, endpoints, speed, and movement state for a later moving-platform
update. Until that update is added, interacting with the lift keeps the existing instant
floor transfer behavior.

Most shafts use the compact freight-cage treatment. A deterministic one-in-eight variant
uses an original exposed megastructure cargo-lift treatment with open guide rails, heavy
overhead structure, and red warning lights.

`adjacency` lines describe sensible facility relationships. Keep related zones linked,
for example security to transit, production to storage, and maintenance to power.

## Adding your own textures

All game material textures are 128x128 PNG files. Put your albedo texture under
`assets/textures/game/`, then add a line to `assets/materials/game.materials`:

```text
material my_panels assets/textures/game/my_panels.png auto auto auto
```

The last three fields are normal, specular, and smoothness maps. `auto` tells the game
to derive those maps from your albedo at load time. You can replace any `auto` with a
path to a hand-authored 128x128 PNG later. Use the material name (`my_panels` above) in
a prop definition or in the theme's `materials` line.

Structural UVs use a fixed world-space scale, so 128x128 textures stay aligned across
separate room and hallway boxes instead of restarting at each piece.
