#version 460 core

#include "include/s3d_backend.glsl"

layout (location = 0) in vec3 aPosition;
layout (location = 1) in vec3 aNormal;
layout (location = 2) in vec2 aTcoord;

layout (location = 3) in mat4 aWorld;
layout (location = 7) in mat3 aNormalMatrix;
layout (location = 10) in vec3 aColor;
layout (location = 11) in float aMaterial;
layout (location = 12) in float aBakedAoIndex;
layout (location = 13) in vec2 aBakedAoFaceSize;

uniform mat4 u_viewProjection;
S3D_RESOURCE(2, 3) uniform samplerBuffer u_bakedAo;
uniform int u_surfacePass;

out vec3 position;
out vec3 normal;
out vec3 instanceColor;
out vec2 boxUv;
flat out int materialIndex;
out float bakedAmbientOcclusion;
flat out vec2 bakedAoFaceSize;

void main()
{
	bool compiledSurface = u_surfacePass != 0;
	vec4 worldPosition = compiledSurface ? vec4(aPosition, 1.0) :
		aWorld * vec4(aPosition, 1.0);
	position = worldPosition.xyz;
	normal = normalize(compiledSurface ? aNormal : aNormalMatrix * aNormal);
	instanceColor = aColor;
	boxUv = aTcoord;
	materialIndex = int(round(aMaterial));
	int bakedAddress = compiledSurface ? int(aBakedAoIndex + 0.5) :
		int(aBakedAoIndex + 0.5) * 24 + gl_VertexID;
	bakedAmbientOcclusion = texelFetch(u_bakedAo, bakedAddress).r;
	bakedAoFaceSize = compiledSurface ? aBakedAoFaceSize : vec2(0.0);
	gl_Position = u_viewProjection * worldPosition;
}
