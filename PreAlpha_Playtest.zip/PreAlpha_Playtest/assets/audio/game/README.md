# Game audio assets

Game-specific audio code lives in `src/game/audio`. This folder contains the replaceable audio
assets it loads. For every name below, the loader accepts `.wav`, `.ogg`, `.mp3`, or `.flac` and
uses the first matching file in that order.

```text
weapons/fire                 (shared fallback when a weapon-specific file is absent)
weapons/c7_fire
weapons/c8_fire
weapons/reload_start
weapons/reload_complete
weapons/select
impacts/metal
movement/footstep_01 through footstep_08
movement/jump
movement/landing
ui/flashlight
ui/ui_donation
interactions/door_open
interactions/door_denied
interactions/pickup
interactions/puzzle
interactions/loot
interactions/lift
interactions/extraction
interactions/denied
ambience/dungeon_loop
music/dungeon_loop
```

Each entry in `assets/weapons/game.weapons` supplies its own extension-free `fire_sound` stem.
The initial armory shares `weapons/c7_fire` until distinct recordings are added; change any
catalog entry to a new stem such as `weapons/c8_fire` to give it a dedicated report.

Short effects are decoded and cached during game-audio loading. Ambience and music are streamed.
Mono files are recommended for positional effects such as doors, impacts, footsteps, and landings.
Stereo is appropriate for music, ambience, UI feedback, and player-owned weapon sounds.

Footstep variants are cached at load time and played in sequence with a subtle pitch change on
every step. Add numbered files without changing code; missing higher-numbered variants are ignored.

You can add the files gradually. Missing assets are reported in the Audio debug panel and are
otherwise harmless. Use **Reload game audio files** in that panel after adding or replacing files.
