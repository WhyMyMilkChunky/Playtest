#version 460 core
#include "include/s3d_backend.glsl"
S3D_RESOURCE(0, 1) uniform sampler2D gibTexture;
layout(location = 0) in vec2 uv;
layout(location = 1) in float light;
layout(location = 0) out vec4 color;
void main() { color = vec4(texture(gibTexture, uv).rgb * light, 1.0); }
