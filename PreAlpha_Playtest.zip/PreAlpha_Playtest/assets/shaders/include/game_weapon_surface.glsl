#include "s3d_backend.glsl"

#if defined(S3D_VULKAN) || defined(S3D_GPU_MODEL)
#define S3D_PORTABLE_MODEL 1
#endif

layout(location = 0) out vec4 FragColor;

#if defined(S3D_PORTABLE_MODEL)
#include "game_model_gpu.glsl"
const int WOUND_COUNT = 8;
const int WOUND_REGION_VECTOR_COUNT = 2;
layout(location = 0) in vec3 localPosition;
layout(location = 1) in vec3 surfaceNormal;
layout(location = 2) in vec2 uv;
layout(location = 3) flat in vec4 materialSettings;
layout(location = 4) in vec3 bodyPosition;
layout(location = 5) flat in vec4 woundSpheres[WOUND_COUNT];
layout(location = 13) flat in vec4 woundRegions[WOUND_REGION_VECTOR_COUNT];
layout(location = 15) flat in float bodyRegion;
#define u_normalStrength materialSettings.x
#define u_specularStrength materialSettings.y
#define u_opacity materialSettings.z
#define u_sunDirection modelFrame.sunDirection.xyz
#define u_worldUp modelFrame.worldUp.xyz
#define u_environmentColor modelFrame.environmentColor.xyz
#define u_lightCount int(materialSettings.w)
#else
const int WOUND_COUNT = 8;
const int WOUND_REGION_VECTOR_COUNT = 2;
in vec3 localPosition;
in vec3 surfaceNormal;
in vec2 uv;
in vec3 bodyPosition;
flat in vec4 woundSpheres[WOUND_COUNT];
flat in vec4 woundRegions[WOUND_REGION_VECTOR_COUNT];
flat in float bodyRegion;
#endif

S3D_RESOURCE(1, 0) uniform sampler2D u_albedo;
S3D_RESOURCE(1, 1) uniform sampler2D u_normalMap;
S3D_RESOURCE(1, 2) uniform sampler2D u_specularMap;
S3D_RESOURCE(1, 3) uniform sampler2D u_smoothnessMap;
#if !defined(S3D_PORTABLE_MODEL)
uniform float u_normalStrength;
uniform float u_specularStrength;
uniform float u_opacity;
uniform vec3 u_sunDirection;
uniform vec3 u_worldUp;
uniform vec3 u_environmentColor;
uniform int u_lightCount;
uniform vec3 u_lightPositions[24];
uniform vec3 u_lightColors[24];
uniform vec3 u_lightDirections[24];
uniform vec4 u_lightParameters[24];
#endif

vec3 ModelLightPosition(int index)
{
#if defined(S3D_PORTABLE_MODEL)
	return modelFrame.lights[index].position.xyz;
#else
	return u_lightPositions[index];
#endif
}

vec3 ModelLightColor(int index)
{
#if defined(S3D_PORTABLE_MODEL)
	return modelFrame.lights[index].color.xyz;
#else
	return u_lightColors[index];
#endif
}

vec3 ModelLightDirection(int index)
{
#if defined(S3D_PORTABLE_MODEL)
	return modelFrame.lights[index].direction.xyz;
#else
	return u_lightDirections[index];
#endif
}

vec4 ModelLightParameters(int index)
{
#if defined(S3D_PORTABLE_MODEL)
	return modelFrame.lights[index].parameters;
#else
	return u_lightParameters[index];
#endif
}

float Pow5(float value)
{
	float squared = value * value;
	return squared * squared * value;
}

float SpecularReflectance(float specularLevel)
{
	return mix(0.025, 0.28, smoothstep(0.04, 0.82, specularLevel));
}

float PixelLightResponse(float value)
{
	float banded = floor(clamp(value, 0.0, 1.0) * 12.0 + 0.5) / 12.0;
	return mix(value, banded, 0.58);
}

mat3 CotangentFrame(vec3 surfaceNormalValue, vec3 surfacePosition, vec2 uvValue)
{
	vec3 positionDx = dFdx(surfacePosition);
	vec3 positionDy = S3D_DFDY(surfacePosition);
	vec2 uvDx = dFdx(uvValue);
	vec2 uvDy = S3D_DFDY(uvValue);
	vec3 perpendicularX = cross(positionDy, surfaceNormalValue);
	vec3 perpendicularY = cross(surfaceNormalValue, positionDx);
	vec3 tangent = perpendicularX * uvDx.x + perpendicularY * uvDy.x;
	vec3 bitangent = perpendicularX * uvDx.y + perpendicularY * uvDy.y;
	float scale = inversesqrt(max(max(dot(tangent, tangent),
		dot(bitangent, bitangent)), 0.00001));
	return mat3(tangent * scale, bitangent * scale, surfaceNormalValue);
}

float RelayDiffuse(vec3 normalValue, vec3 viewDirection, vec3 lightDirection,
	float roughness)
{
	float normalLight = dot(normalValue, lightDirection);
	float normalView = max(dot(normalValue, viewDirection), 0.0);
	float wrap = 0.035 + roughness * 0.18;
	float wrappedLight = clamp((normalLight + wrap) / (1.0 + wrap), 0.0, 1.0);
	float viewReturn = 0.82 + 0.18 * (1.0 - Pow5(1.0 - normalView));
	return wrappedLight * viewReturn * (1.0 - roughness * 0.12);
}

vec3 BeckmannReflection(vec3 lightColor, vec3 normalValue, vec3 tangentValue,
	vec3 bitangentValue, vec3 viewDirection, vec3 lightDirection,
	float specularLevel, float smoothness, float strength)
{
	float normalLight = max(dot(normalValue, lightDirection), 0.0);
	float normalView = max(dot(normalValue, viewDirection), 0.0);
	if (normalLight <= 0.0 || normalView <= 0.0 || strength <= 0.0)
		return vec3(0.0);
	vec3 halfway = normalize(viewDirection + lightDirection);
	float normalHalf = max(dot(normalValue, halfway), 0.001);
	float viewHalf = max(dot(viewDirection, halfway), 0.001);
	float roughness = clamp(1.0 - smoothness, 0.12, 0.92);
	float alphaX = max(roughness * 0.72, 0.075);
	float alphaY = max(roughness * 1.28, 0.105);
	float slopeX = dot(halfway, tangentValue) / alphaX;
	float slopeY = dot(halfway, bitangentValue) / alphaY;
	float normalHalf2 = normalHalf * normalHalf;
	float distribution = exp(-(slopeX * slopeX + slopeY * slopeY) / normalHalf2) /
		(3.14159265 * alphaX * alphaY * normalHalf2 * normalHalf2);
	float geometry = min(1.0, min(2.0 * normalHalf * normalView / viewHalf,
		2.0 * normalHalf * normalLight / viewHalf));
	float reflectance = SpecularReflectance(specularLevel);
	float fresnel = reflectance + (1.0 - reflectance) * Pow5(1.0 - viewHalf);
	float reflectedEnergy = distribution * geometry * fresnel /
		max(4.0 * normalView, 0.001);
	return lightColor * min(reflectedEnergy * strength * 1.25, 1.0);
}

vec3 EnvironmentReflection(vec3 environmentColor, vec3 normalValue,
	vec3 viewDirection, float specularLevel, float smoothness, float strength)
{
	float normalView = max(dot(normalValue, viewDirection), 0.0);
	float reflectance = SpecularReflectance(specularLevel);
	float fresnel = reflectance + (1.0 - reflectance) * Pow5(1.0 - normalView);
	return environmentColor * fresnel * mix(0.24, 0.72, smoothness) * strength;
}

float WoundRegion(int index)
{
	vec4 regionSet = woundRegions[index / 4];
	int component = index % 4;
	if (component == 0) return regionSet.x;
	if (component == 1) return regionSet.y;
	if (component == 2) return regionSet.z;
	return regionSet.w;
}

void ApplyWounds(inout vec3 albedo, inout float specularLevel,
	inout float smoothness)
{
	for (int woundIndex = 0; woundIndex < WOUND_COUNT; ++woundIndex)
	{
		vec4 wound = woundSpheres[woundIndex];
		// Wounds are packed from the front, so an empty slot means the rest are
		// empty too. This keeps unwounded and lightly wounded bodies inexpensive.
		if (wound.w <= 0.0) break;
		float woundRegion = WoundRegion(woundIndex);
		if (bodyRegion >= 0.0 && woundRegion >= 0.0 &&
			abs(bodyRegion - woundRegion) > 0.25) continue;
		vec3 woundOffset = bodyPosition - wound.xyz;
		float inverseRadius = 1.0 / max(wound.w, 0.001);
		float radialDistanceSquared = dot(woundOffset, woundOffset) *
			inverseRadius * inverseRadius;
		// The irregular edge can shrink distance by at most 12%, so fragments
		// outside this bound cannot possibly be touched by the wound.
		if (radialDistanceSquared >= 1.292) continue;
		float radialDistance = sqrt(radialDistanceSquared);
		float irregularity = 0.94 + 0.06 * sin(dot(woundOffset,
			vec3(83.0, 57.0, 71.0)) * inverseRadius);
		radialDistance *= irregularity;
		if (radialDistance >= 1.0) continue;
		float tornEdge = 1.0 - smoothstep(0.70, 1.0, radialDistance);
		float deepCavity = 1.0 - smoothstep(0.12, 0.58, radialDistance);
		albedo = mix(albedo, vec3(0.24, 0.006, 0.008), tornEdge);
		albedo = mix(albedo, vec3(0.018, 0.001, 0.001), deepCavity);
		float wetTissue = max(tornEdge * 0.82, deepCavity * 0.46);
		specularLevel = max(specularLevel, wetTissue);
		smoothness = max(smoothness, max(tornEdge * 0.88,
			deepCavity * 0.62));
	}
}

void main()
{
	vec3 geometricNormal = normalize(surfaceNormal);
	vec2 authoredUv = clamp(uv, vec2(0.004), vec2(0.996));
	vec3 albedo = texture(u_albedo, authoredUv).rgb;
	vec3 mappedNormal = texture(u_normalMap, authoredUv).xyz * 2.0 - 1.0;
	float specularLevel = texture(u_specularMap, authoredUv).r;
	float smoothness = texture(u_smoothnessMap, authoredUv).r;
	ApplyWounds(albedo, specularLevel, smoothness);
	mappedNormal.y = -mappedNormal.y;
	mappedNormal.xy *= 2.25 * u_normalStrength;
	mappedNormal = normalize(mappedNormal);
	mat3 surfaceFrame = CotangentFrame(geometricNormal, localPosition, authoredUv);
	vec3 N = normalize(mix(geometricNormal,
		normalize(surfaceFrame * mappedNormal), 0.92));
	vec3 tangentValue = normalize(surfaceFrame[0] - N * dot(surfaceFrame[0], N));
	vec3 bitangentValue = normalize(cross(N, tangentValue));
	vec3 viewDirection = normalize(-localPosition);
	float roughness = clamp(1.0 - smoothness, 0.08, 0.96);
	vec3 worldUp = normalize(u_worldUp);
	float hemisphere = dot(N, worldUp) * 0.5 + 0.5;
	vec3 ambientField = vec3(0.045, 0.052, 0.072) +
		vec3(0.10, 0.12, 0.17) * hemisphere;

	vec3 sunDirection = normalize(u_sunDirection);
	vec3 sunColor = vec3(0.20, 0.18, 0.15);
	float sunDiffuse = PixelLightResponse(
		RelayDiffuse(N, viewDirection, sunDirection, roughness));
	vec3 directDiffuse = albedo * sunColor * sunDiffuse;
	vec3 directReflection = BeckmannReflection(sunColor, N, tangentValue,
		bitangentValue, viewDirection, sunDirection, specularLevel, smoothness,
		u_specularStrength);
	vec3 reflectionDirection = reflect(-viewDirection, N);
	float reflectedSky = dot(reflectionDirection, worldUp) * 0.5 + 0.5;
	vec3 environmentField = mix(u_environmentColor * 0.55,
		vec3(0.30, 0.39, 0.52), reflectedSky);

	for (int lightIndex = 0; lightIndex < u_lightCount; ++lightIndex)
	{
		vec4 lightParameters = ModelLightParameters(lightIndex);
		vec3 toLight = ModelLightPosition(lightIndex) - localPosition;
		float radius = lightParameters.x;
		float distanceSquared = dot(toLight, toLight);
		if (radius <= 0.0 || distanceSquared >= radius * radius) continue;
		float distanceToLight = sqrt(distanceSquared);
		vec3 lightColor = ModelLightColor(lightIndex);
		vec3 lightDirection = toLight / max(distanceToLight, 0.001);
		float falloff = 1.0 - distanceToLight / radius;
		float attenuation = falloff * falloff * lightParameters.y;
		float style = lightParameters.z;
		if (style > 0.5 && style < 2.5)
		{
			vec3 fromLight = -lightDirection;
			float coneCosine = lightParameters.w;
			float spot = smoothstep(coneCosine, min(coneCosine + 0.18, 0.995),
				dot(fromLight, normalize(ModelLightDirection(lightIndex))));
			attenuation *= spot;
		}
		if (attenuation == 0.0) continue;
		float diffuseResponse = PixelLightResponse(
			RelayDiffuse(N, viewDirection, lightDirection, roughness));
		directDiffuse += albedo * lightColor * attenuation *
			diffuseResponse * 0.92;
		directReflection += BeckmannReflection(
			lightColor * attenuation, N, tangentValue, bitangentValue,
			viewDirection, lightDirection, specularLevel, smoothness,
			u_specularStrength);
	}

	vec3 reflectedLight = min(directReflection + EnvironmentReflection(environmentField,
		N, viewDirection, specularLevel, smoothness, u_specularStrength), vec3(0.72));
	vec3 color = albedo * ambientField * 1.62 + directDiffuse * 1.62 + reflectedLight;
	FragColor = vec4(color, u_opacity);
}
