# Weapon catalog

Open the game editor and choose **Weapons**. The editor reads and writes
`game.weapons`; manual editing is optional.

Each weapon owns its base combat stats, handling multipliers, view-model assets,
fire-sound stem, view placement, and per-upgrade scaling. Sound stems omit the
extension so the audio loader can accept `.wav`, `.ogg`, `.mp3`, or `.flac`.

The first two entries, Warden and Kestrel, are protected because existing saves use
those stable slots. The included armory has eight original near-future weapons:
VKR-71 Warden, VKC-45 Kestrel, HLS-90 Rampart, PXR-14 Veil, DMR-20 Longwatch,
VSP-22 Sparrow, BRC-12 Ram, and HMG-60 Bastion. Number keys `1` through `8`
select them.

Each model has a weapon-specific projected UV unwrap and one runtime material. Its
matching 256x256 albedo is baked from the authored source atlas in
`tools/source_assets/weapons`; the shared texture pipeline derives the normal,
specular, and smoothness maps from that albedo. Running
`tools/build_weapon_library.py` rebuilds the complete library and
`assets/models/weapons/weapon_library_preview.png` without network access. The
runtime remains bounded to 16 catalog slots for future additions.
